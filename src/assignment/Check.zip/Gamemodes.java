package assignment;

/**
 * @author Robin Fritz
 * @version 1.0
 */
public enum Gamemodes {
    /**
     *
     */
    BACKWARD,

    /**
     *
     */
    BARRIER,

    /**
     *
     */
    NOJUMP,

    /**
     *
     */
    TRIPLY
}
